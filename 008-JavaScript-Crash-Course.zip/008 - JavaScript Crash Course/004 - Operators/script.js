const a = 5 + 5;
console.log(a);
const b = (5 + 5) * 5;
console.log(b);

const num1 = 10;
const num2 = "10";
