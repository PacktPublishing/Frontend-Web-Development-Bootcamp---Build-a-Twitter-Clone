const multiply = () => 10 * 5;

console.log(multiply());
