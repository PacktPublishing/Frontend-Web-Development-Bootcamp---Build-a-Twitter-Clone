const a = 10 * '20';
console.log(a);

const b = 'Hello ' + 'there';
console.log(b);

const c = 'a' + 10 + 15;
console.log(c);
