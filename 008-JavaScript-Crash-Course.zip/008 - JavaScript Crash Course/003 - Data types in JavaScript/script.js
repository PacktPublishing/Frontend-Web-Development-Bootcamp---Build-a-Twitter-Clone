const str = 'John is a developer';
console.log(str);
console.log(typeof str);

const num = '30.45';
console.log(num);
console.log(typeof num);

const num1 = 10;
const num2 = 20;
const bool = true;
console.log(typeof bool);

let a;
console.log(a);
console.log(typeof a);

const b = null;
