const list = document.querySelector('.list');
console.log(list);

const lis = document.querySelectorAll('ul li');
console.log(lis);

const listItems = document.querySelectorAll('.list-item');
console.log(listItems);
